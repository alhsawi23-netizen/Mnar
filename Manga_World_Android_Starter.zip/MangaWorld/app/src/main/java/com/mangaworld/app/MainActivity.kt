package com.mangaworld.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import android.net.Uri

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1D2A32)
private val Teal = Color(0xFF55DCE5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MangaWorldApp() }
    }
}

data class Manga(
    val id: Long, val title: String, val author: String, val category: String,
    val cover: Uri? = null, val chapters: List<Chapter> = emptyList()
)
data class Chapter(val id: Long, val title: String, val pages: List<Uri>, val cover: Uri? = null)

@Composable
fun MangaWorldApp() {
    var screen by remember { mutableStateOf("library") }
    var selected by remember { mutableStateOf<Manga?>(null) }
    var readerChapter by remember { mutableStateOf<Chapter?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("عام") }
    var cover by remember { mutableStateOf<Uri?>(null) }
    var pageUris by remember { mutableStateOf(listOf<Uri>()) }
    var chapters by remember { mutableStateOf(listOf<Chapter>()) }
    var items by remember { mutableStateOf(listOf<Manga>()) }
    var direction by remember { mutableStateOf("من اليمين إلى اليسار") }
    var vertical by remember { mutableStateOf(true) }
    var continuous by remember { mutableStateOf(true) }
    var grayscale by remember { mutableStateOf(false) }
    var dim by remember { mutableFloatStateOf(0f) }
    var autoSpeed by remember { mutableFloatStateOf(150f) }
    var margin by remember { mutableFloatStateOf(0f) }
    var preloadAll by remember { mutableStateOf(false) }
    var hideDouble by remember { mutableStateOf(true) }
    var background by remember { mutableStateOf<Uri?>(null) }

    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { cover = it }
    val pagesPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { pageUris = it }
    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { background = it }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Teal, background = Ink, surface = Panel, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = { Text("Manga World", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, "الإعدادات")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = screen == "library", onClick = { screen = "library" },
                        icon = { Icon(Icons.Default.CollectionsBookmark, null) }, label = { Text("المكتبة") })
                    NavigationBarItem(selected = screen == "authors", onClick = { screen = "authors" },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("المؤلفون") })
                    NavigationBarItem(selected = screen == "add", onClick = { screen = "add" },
                        icon = { Icon(Icons.Default.Add, null) }, label = { Text("إضافة") })
                    NavigationBarItem(selected = screen == "cloud", onClick = { screen = "cloud" },
                        icon = { Icon(Icons.Default.Cloud, null) }, label = { Text("السحابة") })
                }
            }
        ) { padding ->
            when (screen) {
                "library" -> LibraryScreen(items, padding, onOpen = { selected = it; screen = "details" })
                "authors" -> AuthorsScreen(items, padding) { name -> items.firstOrNull { it.author == name }?.let { selected = it; screen = "details" } }
                "add" -> AddScreen(title, { title = it }, author, { author = it }, category, { category = it },
                    cover, { coverPicker.launch("image/*") }, { 
                        if (title.isNotBlank()) {
                            items = items + Manga(System.currentTimeMillis(), title, author.ifBlank { "غير معروف" }, category, cover)
                            title = ""; author = ""; cover = null; screen = "library"
                        }
                    }, padding)
                "cloud" -> CloudScreen(padding)
                "details" -> selected?.let { manga ->
                    DetailsScreen(manga, padding, onAddChapter = { pagesPicker.launch("image/*") },
                        onRead = { ch -> readerChapter = ch; screen = "reader" },
                        onChapterPages = { pages ->
                            val updated = manga.copy(chapters = manga.chapters + Chapter(System.currentTimeMillis(), "الفصل ${manga.chapters.size + 1}", pages))
                            items = items.map { if (it.id == manga.id) updated else it }
                            selected = updated
                        })
                }
                "reader" -> ReaderScreen(readerChapter, padding, vertical, grayscale, dim, margin, continuous)
            }
        }
        if (showSettings) {
            ReaderSettingsDialog(
                direction, { direction = it }, vertical, { vertical = it },
                continuous, { continuous = it }, autoSpeed, { autoSpeed = it },
                margin, { margin = it }, grayscale, { grayscale = it },
                dim, { dim = it }, preloadAll, { preloadAll = it }, hideDouble, { hideDouble = it },
                { backgroundPicker.launch("image/*") }, { showSettings = false }
            )
        }
    }
}

@Composable
fun LibraryScreen(items: List<Manga>, padding: PaddingValues, onOpen: (Manga) -> Unit) {
    val columns = if (LocalConfiguration.current.screenWidthDp >= 600) 4 else 2
    Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
        Text("مكتبتك", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("${items.size} عمل", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("مكتبتك فارغة حالياً\nاضغط «إضافة» لإضافة أول عمل", color = Color.LightGray)
            }
        } else LazyVerticalGridCompat(items, columns, onOpen)
    }
}

@Composable
fun LazyVerticalGridCompat(items: List<Manga>, columns: Int, onOpen: (Manga) -> Unit) {
    // Adaptive card grid: naturally expands for tablets and narrows for phones.
    Column {
        items.chunked(columns).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { manga ->
                    Card(Modifier.weight(1f).padding(bottom = 12.dp).clickable { onOpen(manga) },
                        colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column {
                            if (manga.cover != null) AsyncImage(manga.cover, null, Modifier.fillMaxWidth().height(175.dp))
                            else Box(Modifier.fillMaxWidth().height(175.dp).background(Color(0xFF30414B)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MenuBook, null, tint = Teal, modifier = Modifier.size(48.dp))
                            }
                            Column(Modifier.padding(10.dp)) {
                                Text(manga.title, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(manga.author, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                Text(manga.category, color = Teal, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun AddScreen(title: String, setTitle: (String) -> Unit, author: String, setAuthor: (String) -> Unit,
              category: String, setCategory: (String) -> Unit, cover: Uri?, pickCover: () -> Unit,
              save: () -> Unit, padding: PaddingValues) {
    Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إضافة عمل جديد", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(title, setTitle, label = { Text("اسم العمل") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(author, setAuthor, label = { Text("اسم المؤلف") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(category, setCategory, label = { Text("التصنيف") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = pickCover, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Image, null); Text("اختيار صورة عرض") }
        cover?.let { AsyncImage(it, null, Modifier.fillMaxWidth().height(180.dp)) }
        Button(onClick = save, modifier = Modifier.fillMaxWidth(), enabled = title.isNotBlank()) { Text("حفظ العمل") }
    }
}

@Composable
fun AuthorsScreen(items: List<Manga>, padding: PaddingValues, open: (String) -> Unit) {
    val authors = items.map { it.author }.distinct()
    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("المؤلفون", style = MaterialTheme.typography.headlineMedium)
        authors.forEach { name ->
            ListItem(headlineContent = { Text(name) }, supportingContent = { Text("${items.count { it.author == name }} أعمال") },
                leadingContent = { Icon(Icons.Default.AccountCircle, null, tint = Teal) },
                modifier = Modifier.clickable { open(name) })
        }
        if (authors.isEmpty()) Text("سيظهر المؤلفون هنا بعد إضافة الأعمال.", color = Color.LightGray)
    }
}

@Composable
fun DetailsScreen(manga: Manga, padding: PaddingValues, onAddChapter: () -> Unit,
                  onRead: (Chapter) -> Unit, onChapterPages: (List<Uri>) -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) onChapterPages(uris)
    }
    Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(manga.title, style = MaterialTheme.typography.headlineMedium)
        Text("المؤلف: ${manga.author}  •  ${manga.category}", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { picker.launch("image/*") }) { Icon(Icons.Default.Add, null); Text("إضافة فصل من الجهاز") }
        manga.chapters.forEach { chapter ->
            ListItem(headlineContent = { Text(chapter.title) }, supportingContent = { Text("${chapter.pages.size} صفحة") },
                leadingContent = { Icon(Icons.Default.MenuBook, null, tint = Teal) },
                trailingContent = { Icon(Icons.Default.ChevronRight, null) },
                modifier = Modifier.clickable { onRead(chapter) })
        }
        if (manga.chapters.isEmpty()) Text("لا توجد فصول بعد.", color = Color.LightGray)
    }
}

@Composable
fun ReaderScreen(chapter: Chapter?, padding: PaddingValues, vertical: Boolean, grayscale: Boolean,
                 dim: Float, margin: Float, continuous: Boolean) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    Column(Modifier.padding(padding).fillMaxSize().background(Color.Black)) {
        Text(chapter?.title ?: "القارئ", Modifier.padding(12.dp), color = Color.White)
        if (chapter == null || chapter.pages.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("أضف صفحات للفصل أولاً", color = Color.White) }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(chapter.pages) { uri ->
                AsyncImage(model = uri, contentDescription = "صفحة مانجا",
                    modifier = Modifier.fillMaxWidth().padding(bottom = margin.dp)
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offsetX += pan.x; offsetY += pan.y
                            }
                        }.graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY))
            }
        }
    }
}

@Composable
fun CloudScreen(padding: PaddingValues) {
    Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Default.CloudQueue, null, tint = Teal, modifier = Modifier.size(48.dp))
        Text("Google Drive", style = MaterialTheme.typography.headlineSmall)
        Text("واجهة السحابة جاهزة للربط. يتطلب تفعيل OAuth وإضافة Client ID الخاص بتطبيقك في Google Cloud Console.")
        Button(onClick = {}) { Icon(Icons.Default.Link, null); Text("إعداد ربط Google Drive") }
        Text("بعد إعداد OAuth ستتمكن من رفع الفصول وتنزيلها مباشرة من Drive.", color = Color.LightGray)
    }
}

@Composable
fun ReaderSettingsDialog(direction: String, setDirection: (String) -> Unit,
                         vertical: Boolean, setVertical: (Boolean) -> Unit,
                         continuous: Boolean, setContinuous: (Boolean) -> Unit,
                         speed: Float, setSpeed: (Float) -> Unit, margin: Float, setMargin: (Float) -> Unit,
                         grayscale: Boolean, setGrayscale: (Boolean) -> Unit, dim: Float, setDim: (Float) -> Unit,
                         preload: Boolean, setPreload: (Boolean) -> Unit, hideDouble: Boolean, setHideDouble: (Boolean) -> Unit,
                         pickBackground: () -> Unit, close: () -> Unit) {
    AlertDialog(onDismissRequest = close, title = { Text("إعدادات القراءة") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("اتجاه القراءة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("من اليسار إلى اليمين", "من اليمين إلى اليسار", "من الأعلى للأسفل").forEach { item ->
                        FilterChip(selected = direction == item, onClick = { setDirection(item) }, label = { Text(item, fontSize = 10.sp) })
                    }
                }
                Text("هامش الصور: ${margin.toInt()} px")
                Slider(value = margin, onValueChange = setMargin, valueRange = 0f..40f)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("التمرير المستمر"); Spacer(Modifier.weight(1f)); Switch(continuous, setContinuous) }
                Text("سرعة التمرير: ${speed.toInt()} px/s")
                Slider(value = speed, onValueChange = setSpeed, valueRange = 30f..600f)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("ملاءمة العرض العمودي"); Spacer(Modifier.weight(1f)); Switch(vertical, setVertical) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("تحميل كل الصور مسبقاً"); Spacer(Modifier.weight(1f)); Switch(preload, setPreload) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("إخفاء الأدوات بلمستين"); Spacer(Modifier.weight(1f)); Switch(hideDouble, setHideDouble) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("صفحات بتدرج رمادي"); Spacer(Modifier.weight(1f)); Switch(grayscale, setGrayscale) }
                Text("تعتيم الصفحات: ${dim.toInt()}%")
                Slider(value = dim, onValueChange = setDim, valueRange = 0f..80f)
                OutlinedButton(onClick = pickBackground, modifier = Modifier.fillMaxWidth()) { Text("اختيار خلفية التطبيق") }
            }
        },
        confirmButton = { TextButton(onClick = close) { Text("تم") } }
    )
}
